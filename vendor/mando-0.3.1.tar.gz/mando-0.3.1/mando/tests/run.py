#!/bin/env python

if __name__ == '__main__':
    import unittest
    from mando.tests.test_core import *
    from mando.tests.test_utils import *

    unittest.main()
