rson stands for "Readable Serial Object Notation"

It is useful for configuration files.

More info at http://code.google.com/p/rson

