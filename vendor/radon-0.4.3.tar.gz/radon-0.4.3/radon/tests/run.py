if __name__ == '__main__':
    import unittest
    from radon.tests.test_complexity_visitor import *
    from radon.tests.test_complexity_utils import *
    from radon.tests.test_raw import *
    from radon.tests.test_halstead import *
    from radon.tests.test_other_metrics import *
    from radon.tests.test_cli import *

    unittest.main()
