.. _pyramid_chameleon_api:

:mod:`pyramid_chameleon` API
----------------------------

.. automodule:: pyramid_chameleon
.. autofunction:: includeme


.. automodule:: pyramid_chameleon.interfaces
.. autointerface:: IChameleonLookup
.. autointerface:: IChameleonTranslate

.. automodule:: pyramid_chameleon.renderer


