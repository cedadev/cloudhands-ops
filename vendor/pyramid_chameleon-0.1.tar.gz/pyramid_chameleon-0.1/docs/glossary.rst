.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   Chameleon
     Chameleon_ is an open-source template engine written in Python_.

.. _Chameleon: http://pagetemplates.org
.. _Python: http://python.org
