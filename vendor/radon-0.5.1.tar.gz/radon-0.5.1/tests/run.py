if __name__ == '__main__':
    import nose
    nose.main()
