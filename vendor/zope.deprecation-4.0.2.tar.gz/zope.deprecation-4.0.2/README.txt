``zope.deprecation`` README
===========================

This package provides a simple function called ``deprecated(names, reason)``
to mark deprecated modules, classes, functions, methods and properties.

Please see http://docs.zope.org/zope.deprecation/ for the documentation.

