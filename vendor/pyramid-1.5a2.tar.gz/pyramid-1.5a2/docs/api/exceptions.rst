.. _exceptions_module:

:mod:`pyramid.exceptions`
----------------------------

.. automodule:: pyramid.exceptions

  .. autoclass:: PredicateMismatch

  .. autoclass:: Forbidden

  .. autoclass:: NotFound

  .. autoclass:: ConfigurationError

  .. autoclass:: URLDecodeError
