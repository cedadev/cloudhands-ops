sqla_demo README
==================

Getting Started
---------------

- cd <directory containing this file>

- $venv/bin/python setup.py develop

- $venv/bin/initialize_sqla_demo_db development.ini

- $venv/bin/pserve development.ini

